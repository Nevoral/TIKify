package templ

// Binary builds set this version string. goreleaser sets the value using Go build ldflags.
var Version string
