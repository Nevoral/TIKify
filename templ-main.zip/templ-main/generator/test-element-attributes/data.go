package testelementattributes

type person struct {
	name      string
	email     string
	important bool
}
