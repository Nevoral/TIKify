package testhtml

type person struct {
	name  string
	email string
}
