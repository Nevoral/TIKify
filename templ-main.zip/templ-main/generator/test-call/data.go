package testcall

type person struct {
	name  string
	email string
}
