package testcssusage

const red = "#ff0000"
