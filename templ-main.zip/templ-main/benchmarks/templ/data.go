package testhtml

type Person struct {
	Name  string
	Email string
}
