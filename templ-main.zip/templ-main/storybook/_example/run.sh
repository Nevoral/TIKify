go run ./local/main.go
