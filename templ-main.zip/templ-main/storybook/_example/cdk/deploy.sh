# Build the Storybook.
`cd ../lambda && go run main.go build`
# Deploy it.
cdk deploy
