## Tasks

### generate

```sh
templ generate
```

### deploy

requires: generate
dir: cdk

```sh
cdk deploy
```

### deploy-hotswap

requires: generate
dir: cdk

```sh
cdk deploy --hotswap
```
